#include <iostream>
#include <string.h>
#include "Command.h"
using namespace std;

int main() {
    Command command;
    command.init();
    command.start();
    return 0;
}
